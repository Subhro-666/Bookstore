import '../components/BookCard.css';

const BookCard = ({ book }) => {
  const handleBuy = () => {
    alert(`You selected "${book.title}"!`);
  };

  return (
    <div className="book">
      <img src={book.image} alt={book.title} />
      <h3>{book.title}</h3>
      <p>by {book.author}</p>
      <button className="btn-grad" onClick={handleBuy} >Buy Now</button>
    </div>
  );
};

export default BookCard;
