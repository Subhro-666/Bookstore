import { useState } from 'react';
import './App.css';
import BookCard from './components/BookCard';

const books = [
  {
    title: 'Dune',
    author: 'Frank Herbert',
    image: 'https://covers.openlibrary.org/b/id/15092781-L.jpg'
  },
  {
    title: 'Robinson Crusoe',
    author: 'Daniel Defoe',
    image: 'https://archive.org/download/robinsoncrusoeau00defo/page/cover_w500_h500.jpg'
  },
  {
    title: 'The Invisible Man',
    author: 'H. G. Wells',
    image: 'https://covers.openlibrary.org/b/id/11475787-L.jpg'
  },
  {
    title: "Harry Potter",
    author: 'J.K. Rowling',
    image: 'https://covers.openlibrary.org/b/id/7984916-L.jpg'
  },
  {
    title: "The Merchant of Venice",
    author: 'William Shakespeare',
    image: 'https://covers.openlibrary.org/b/id/10786418-L.jpg'
  },
  {
    title: "Game of Thrones",
    author: 'George R. R. Martin',
    image: 'https://covers.openlibrary.org/b/id/15101997-L.jpg'
  },
  {
    title: "My Fault",
    author: 'Mercedes Ron',
    image: 'https://covers.openlibrary.org/b/id/14369403-L.jpg'
  },
  {
    title: "Half Girlfriend",
    author: 'Chetan Bhagat',
    image: 'https://covers.openlibrary.org/b/id/15100312-L.jpg'
  }
];

function App() {
  const [search, setSearch] = useState('');

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(search.toLowerCase()) ||
    book.author.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="App">
      <header>
        <h1>📚 The Last Page</h1>
        <div className="search-container">
    <span className="search-icon">🔍</span>
        <input
          type="text"
          placeholder="Search for books..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        </div>
      </header>

      <main>
        {filteredBooks.map((book, index) => (
          <BookCard key={index} book={book} />
        ))}
      </main>

      <footer>
        <p>Copyright | &copy; 2025 All Rights Reserved, TheLastPage.com</p>
      </footer>
    </div>
  );
}

export default App;
